//***************************For Deployment************************************************************

export const environment = {
  production: true,
  apiUrl: 'https://near2me.app/api',
  firebase: {
    apiKey: 'AIzaSyAwklkhenh2ePYSoCQwNcHrvj8oSFXUHYQ',
    authDomain: 'amigosianotification.firebaseapp.com',
    projectId: 'amigosianotification',
    storageBucket: 'amigosianotification.appspot.com',
    messagingSenderId: '951505680836',
    appId: '1:951505680836:web:70a894af7dbf7661c70c91',
    measurementId: 'G-BPZ19BBTJM',
    vapidKey:
      'BHgCD3gf_ToGcBQQLmyCRrCPjzUqLu9_adkW4on12rqSXonn9psz3P26Q9kQlp2h-6Rp99V-IHkRyU15loDFlCg',
  },
  googleMapsAPIKey: 'AIzaSyAt8wMXTeF24HLaV2_rxZYsLYtxNKUAJ-A',
};
