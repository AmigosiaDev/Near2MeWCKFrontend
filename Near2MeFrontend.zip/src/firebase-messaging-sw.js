importScripts("https://www.gstatic.com/firebasejs/10.0.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging-compat.js");
firebase.initializeApp({
 apiKey: "AIzaSyAwklkhenh2ePYSoCQwNcHrvj8oSFXUHYQ",
 authDomain: "amigosianotification.firebaseapp.com",
 projectId: "amigosianotification",
 storageBucket: "amigosianotification.appspot.com",
 messagingSenderId: "951505680836",
 appId: "1:951505680836:web:70a894af7dbf7661c70c91",
 measurementId: "G-BPZ19BBTJM"
});
const messaging = firebase.messaging();
